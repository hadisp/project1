@extends('layouts.main')
@section('content')
    <div class="panel panel-default">
        <div class="panel-heading">Panel Heading</div>
        <div class="panel-body">Panel Content</div>
    </div>
@stop