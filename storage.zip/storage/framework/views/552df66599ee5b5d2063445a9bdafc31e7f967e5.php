<?php $__env->startSection('content'); ?>
    
        
        
            
                
                
                
                
            
        
    
    <div class="jumbotron text-center" style="background-color: white;padding:5px;margin-bottom:20px "><h3>ایجاد دسته غذا </h3></div>
    <div class="jumbotron" style="background-color: white;padding: 5%" >
        <form class="form-horizontal"method="post" action="<?php echo e(route('admin.storefoodtype')); ?>" dir="rtl">
            <?php echo e(csrf_field()); ?>

            <?php echo e(method_field('post')); ?>

            <div class="form-group">
                <div class="col-sm-10">
                    <input type="text" class="form-control"  name="name">
                </div>
                <label class="control-label col-sm-2" for="email"> نام:</label>
            </div>

            <div class="form-group">
                <div class="col-sm-offset-2 col-sm-10">
                    <button type="submit" class="btn btn-default">ثبت</button>
                </div>
            </div>
        </form>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>