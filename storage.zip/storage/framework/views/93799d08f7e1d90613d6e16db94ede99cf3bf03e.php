<?php $__env->startSection('content'); ?>
    
        
            

                
                
                
                
            
            

        

    
    <div class="container" style="padding: 3%">
        <ul class="list-group text-right">
            <li class="list-group-item "  style="background-color:#D4AF37;color: black;"><h3>فاکتور خرید</h3></li>
            <?php if($foodorders==!null): ?>
            <?php $__currentLoopData = $foodorders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="list-group-item " dir="rtl" style="background-color:whitesmoke;" >
                <div class="row">
                    <div class="col-md-4"><h3><?php echo e($order->name); ?></h3></div>
                    <div class="col-md-4"><h3>تعداد :<?php echo e($order->qty); ?> </h3></div>
                    <div class="col-md-4"><h3><?php echo e($order->total); ?></h3></div>
                </div>
            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <li class="list-group-item " dir="rtl" style="background-color:whitesmoke;" >
                    <h3>فاکتور شما خالی است!لطفا خرید کنید.</h3>
                </li>
            <?php endif; ?>
        </ul>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>