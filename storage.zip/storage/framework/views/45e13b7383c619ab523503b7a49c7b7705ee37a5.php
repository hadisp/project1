<?php $__env->startSection('content'); ?>
    <script>

        $(document).ready(function () {
//            $("#CartMsg").hide();
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $food): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            $("#upCart<?php echo e($food->id); ?>").on('change keyup',function () {
                var newQty=$("#upCart<?php echo e($food->id); ?>").val();
                var rowId=$("#rowID<?php echo e($food->id); ?>").val();

                $.ajax({
                    url:'<?php echo e(url('/cart/update/')); ?>',
                    data:'rowID=' + rowId + '&newQty=' + newQty,
                    type:'get',
                    success:function(response) {
//                        $("#CartMsg").show();
//                        console.log(response);
//                        $("#CartMsg").html(response);
                    }
                });
            });
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        });
    </script>


<div class="cart">
    <div class="container" dir="rtl">

        <div class=" shopping-cart ">

            <div class=" title-style  text-center" >

                <h3><i class="fa fa-shopping-cart" aria-hidden="true"></i> سبد خرید</h3>
                <span class="fa fa-chevron-down fa-2x"></span>

            </div>
          <?php if(Cart::count()!=='0'): ?>
<div class="">
            <div class=" align-content-center" >
                <!-- PRODUCT -->
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $food): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <input type="hidden" id="rowID<?php echo e($food->id); ?>" value="<?php echo e($food->rowId); ?>">
                    <div class="row">
                        <div class="col-12 col-sm-12 col-md-2 text-center">
                            <img class="img-responsive" src="http://placehold.it/120x80" alt="prewiew" width="120" height="80">
                        </div>
                        <div class="col-12 text-sm-center col-sm-12 text-md-right t col-md-6">
                            <h4 class="product-name d-flex  justify-content-center"><strong><?php echo e($food->name); ?></strong></h4>
                        </div>
                        <div class="col-12 col-sm-12 text-sm-center col-md-4 text-md-left row">
                            <div class="col-6 col-sm-3 col-md-6 text-md-left" style="padding-top: 5px">
                                <h6><strong><?php echo e($food->price); ?> <span class="text-muted">x</span></strong></h6>
                            </div>
                            <div class="col-6 col-sm-4 col-md-4">
                                <div class="quantity">

                                    <input type="number"   class="qty" min="1" name="count"  value="<?php echo e($food->qty); ?>" id="upCart<?php echo e($food->id); ?>">
                                </div>
                            </div>
                            <div class="col-12 col-sm-2 col-md-2 text-right  d-flex  justify-content-center">

                                <a class="" href="<?php echo e(url('cart/remove')); ?>/<?php echo e($food->rowId); ?>" >
                                    <button type="button" class="btn btn-outline-danger btn-xs" >
                                    <i class="fa fa-trash" aria-hidden="true">

                                    </i>
                                </button>
                                </a>

                            </div>
                        </div>
                    </div>

                    <hr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
            <div class=" row ">
                        <div class="col-6 center-block ">
                            <a href="<?php echo e(url('checkout')); ?>"><button type="submit" class="btn btn-outline-info" >ادامه خرید</button></a>
                            <a class="" href="<?php echo e(url('cart/updatebutton')); ?>"><button class="btn btn-outline-success "> به روز رسانی قیمت ها </button></a>
                        </div>
                    <div class="pull-right" style="margin: 5px">
                        قیمت کل:  <b><?php echo e(Cart::total()); ?></b>

                    </div>

            </div>
</div>
              <?php else: ?>
            <h3>cart is empty</h3>
              <?php endif; ?>

        </div>
    </div>
</div>


    
        
            
        
    
        


 
     

    
    
    
     
     
     
 



 



     
     
     
 
     

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>