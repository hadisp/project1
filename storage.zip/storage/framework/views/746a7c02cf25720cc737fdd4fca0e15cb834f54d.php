
    
        
    
        
            
                    
                        
                            
                            
                            
                            
                        
                    
            
    
        
    

    <?php $__currentLoopData = $foods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $food): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4 jumbotron">
            <div class="box" >
                <a href="<?php echo e(route('menu.food',[$food->id])); ?>"><img class="img-thumbnail img-responsive" src="/storage/<?php echo e($food->image); ?>"></a>
                <h4><?php echo e($food->name); ?></h4>
                <p  class="font-weight-light"><?php echo e($food->description); ?></p>
                <button class="btn btn-shop  food" id="<?php echo e($food->id); ?>"  > سبد خرید</button>
            </div>
        </div>
        
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

