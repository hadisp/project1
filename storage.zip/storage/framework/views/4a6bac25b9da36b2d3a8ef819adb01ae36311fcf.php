<?php $__env->startSection('content'); ?>
    <div class="jumbotron text-center" style="background-color: white;padding:5px;margin-bottom:20px ">
        <h3>ویرایش غذا </h3>
        <a href="<?php echo e(route('admin.foodlist')); ?>"><button class="btn btn-info">بازگشت به لیست</button></a>
    </div>
    <div class="jumbotron" style="background-color: white;padding: 5%" >
        <form class="form-horizontal" method="post" action="<?php echo e(route('admin.updatefood',[$food->id])); ?>"   enctype="multipart/form-data" dir="rtl">
            <?php echo e(csrf_field()); ?>

            <?php echo e(method_field('patch')); ?>

            <div class="form-group">
                <div class="col-sm-10">
                    <input type="text" class="form-control"  name="name" value="<?php echo e($food->name); ?>" >
                </div>
                <label class="control-label col-sm-2" for="email"> نام:</label>
            </div>
            <div class="form-group">
                <div class="col-sm-10">
                    <input type="text" class="form-control"  name="price" value="<?php echo e($food->price); ?>">
                </div>
                <label class="control-label col-sm-2" for="pwd"> قیمت:</label>
            </div>
            <div class="form-group">

                <div class="col-sm-10">
                    <textarea  class="form-control"  name="description" ><?php echo e($food->description); ?></textarea>
                </div>
                <label class="control-label col-sm-2" for="pwd">   توضیح:</label>
            </div>
            <div class="form-group">
                <label>دسته بندی:</label>
                <select class="form-control" name="foodtype"  >
                    <?php echo e($db_selected_value=$food->type_id); ?>

                    <?php $__currentLoopData = $foodtypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foodtype): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($foodtype->id); ?>" <?php echo e($db_selected_value == $foodtype->id ? 'selected' : ''); ?>><?php echo e($foodtype->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group">
                <label class="checkbox-inline"> پیشنهاد سرآشپز:</label>
                <label class="checkbox-inline"><input type="radio" name="sign" value="y" <?php echo e($food->sign == 'y' ? 'checked' : ''); ?>>بله</label>
                <label class="checkbox-inline"><input type="radio" name="sign" value="n" <?php echo e($food->sign == 'n' ? 'checked' : ''); ?>>نه</label>
            </div>
            <div class="form-group">
                <label class="checkbox-inline"> آپلود تصویر:</label>
                <input type="file" name="file">
            </div>
            <div class="form-group">
                <div class="col-sm-offset-2 col-sm-10">
                    <button type="submit" class="btn btn-default">ثبت</button>
                </div>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>