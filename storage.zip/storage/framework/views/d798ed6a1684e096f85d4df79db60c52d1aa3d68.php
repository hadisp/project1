<?php $__env->startSection('content'); ?>
    <div class="jumbotron text-center" style="background-color: white;padding:5px;margin-bottom:20px "><h3>لیست دسته ها </h3></div>
    <div class="row " dir="rtl">
        <div class="col-md-12 col-sm-12 col-xs-12 pull-right"  >


                <ul class="list-group" >
                    <?php $__currentLoopData = $foodtypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foodtype): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-group-item" style="padding:5%;">
                            <div class="row">
                                <div class="pull-right">
                                    <div class="">نام:<?php echo e($foodtype->name); ?></div>
                                </div>
                                <div class="pull-left">
                                    <a class="pull-right" href="<?php echo e(route('admin.editfoodtype',[$foodtype->id])); ?>"><button class="btn btn-info">ویرایش</button></a>
                                    <form class="pull-right"  method="post" action="<?php echo e(route('admin.deletefoodtype',[$foodtype->id])); ?>">
                                        <?php echo e(csrf_field()); ?>

                                        <?php echo e(method_field('delete')); ?>

                                        <button class="btn btn-warning"><i class=" fa fa-trash"></i></button>
                                    </form>
                                </div>
                            </div>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>