<?php $__env->startSection('content'); ?>

    <div class="main text-center ">
        <div class="title-style">
            <h2 >پیشنهاد سر آشپز </h2>
            <span class="fa fa-chevron-down fa-2x"></span>
        </div>
        <div class="row col-md-12">
            <?php $__currentLoopData = $foods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $food): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($food->sign=='y'): ?>

                    <div class="col-md-4 jumbotron ">
                        <div class="box">
                            <img class="img-thumbnail img-responsive" src="/image/images.jpg">
                            <h4><?php echo e($food->name); ?></h4>
                            <p  class="font-weight-light">.این نوشته برای تست است.این نوشته برای تست است.این نوشته برای تست است. این نوشته برای تست است</p>
                            <button class="btn btn-shop food" id="<?php echo e($food->id); ?>">
                                <a
                                        
                                > سبد خرید</a></button>
                        </div>
                    </div>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    
        
            
            
        

        
        
                
         
        
        
            
                
                    
                        
                        
                        
                        
                    
                
            
        
    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>