<?php $__env->startSection('content'); ?>
    <div class="menu text-center " id="menu">
        <div class="title-style">
            <h2>منو </h2>
            <span class="fa fa-chevron-down fa-2x"></span>
        </div>

        <div class="justify-content-center justify-content-center">
            <?php $__currentLoopData = $foodtypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foodtype): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <button class="btn btn-types foodtype"  id="<?php echo e($foodtype->id); ?>" name="foodtype"><?php echo e($foodtype->name); ?></button>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="row col-md-12 ajax">
            <?php $__currentLoopData = $foodtype->foods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $food): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4 jumbotron ">
                    <div class="box">
                        <a href="<?php echo e(route('menu.food',[$food->id])); ?>"> <img class="img-thumbnail img-responsive" src="/storage/<?php echo e($food->image); ?>" ></a>
                        <h4><?php echo e($food->name); ?></h4>
                        <p  class="font-weight-light"><?php echo e($food->description); ?></p>
                            <button class="btn btn-shop food" id="<?php echo e($food->id); ?>"  > سبد خرید</button>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>