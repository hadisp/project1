<?php $__env->startSection('content'); ?>


    <div class="jumbotron text-center" style="background-color: white;padding:5px;margin-bottom:20px "><h3>نظرات </h3></div>

    <div class="row " dir="rtl">
            <div class="col-md-12 col-sm-12 col-xs-12 pull-right"  >
              <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <ul class="list-group" >
                        <li class="list-group-item" style="padding-right: 5%" >
                            <div class="row">
                                <a href="<?php echo e(url('/menu/food')); ?>/<?php echo e($comment->food_id); ?>}}"><h3><?php echo e($comment->food->name); ?></h3></a>
                                <p><?php echo e($comment->food->description); ?></p>
                            </div>
                        </li>
                        <li class="list-group-item" style="padding-right: 5%" >
                            <div class="row">
                                <h4>نام : <?php echo e($comment->name); ?> </h4>
                                <p>ایمیل : <?php echo e($comment->email); ?></p>
                                <p><?php echo e($comment->comment); ?></p>
                            </div>
                            <div class="row">
                                <?php if($comment->deleted_at==null): ?>
                                <form class="pull-right" method="post" action="<?php echo e(route('admin.deletecomment',[$comment->id])); ?>">
                                <?php echo e(csrf_field()); ?>

                                <button class="btn btn-warning">حذف نظر</button>
                                </form>
                                <?php else: ?>
                                <form class="pull-right" method="post" action="<?php echo e(route('admin.undeletecomment',[$comment->id])); ?>">
                                <?php echo e(csrf_field()); ?>

                                <button class="btn btn-default">تایید نظر</button>
                                </form>
                                <?php endif; ?>
                                <form class="pull-right" method="post" action="<?php echo e(route('admin.enforcedeletecomment',[$comment->id])); ?>">
                                <?php echo e(csrf_field()); ?>

                                <button class="btn btn-danger">حذف همیشگی نظر</button>
                                </form>
                            </div>
                        </li>
                    </ul>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>