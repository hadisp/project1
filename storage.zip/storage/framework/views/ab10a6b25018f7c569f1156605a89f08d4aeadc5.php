<?php $__env->startSection('content'); ?>
    <div class="jumbotron text-center" style="background-color: white;padding:5px;margin-bottom:20px "><h3>لیست غذا ها </h3></div>

    <div class="row " dir="rtl">
        <div class="col-md-12 col-sm-12 col-xs-12 pull-right"  >
            <?php $__currentLoopData = $foodtypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foodtype): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <ul class="list-group" >
                    <li class="list-group-item active" ><h3><?php echo e($foodtype->name); ?></h3></li>
                    <?php $__currentLoopData = $foodtype->foods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $food): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="list-group-item" style="padding:5%;">
                        <div class="row">
                            <div class="col-md-2"><img src="/storage/<?php echo e($food->image); ?>" width="100" height="100"></div>
                            <div class="col-md-10">
                            <div class="">نام:<?php echo e($food->name); ?></div>
                            <div class="">قیمت:<?php echo e($food->price); ?></div>
                             <div class="">توضیح:<?php echo e($food->description); ?></div>
                                <div class="row">
                                    <a class="pull-right" href="<?php echo e(route('admin.editfood',[$food->id])); ?>"><button class="btn btn-info">ویرایش</button></a>
                                   <form class="pull-right"  method="post" action="<?php echo e(route('admin.deletefood',[$food->id])); ?>">
                                       <?php echo e(csrf_field()); ?>

                                       <?php echo e(method_field('delete')); ?>

                                    <button class="btn btn-warning"><i class=" fa fa-trash"></i></button>
                                   </form>
                                </div>
                            </div>
                        </div>
                    </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>