<?php $__env->startSection('content'); ?>

    <a href="<?php echo e(route('admin.createfood')); ?>">add new food</a>
    <br>
    <a href="<?php echo e(route('admin.createfoodtype')); ?>">add new food type</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>